// Wait for the DOM to load before executing scripts
document.addEventListener("DOMContentLoaded", function () {
    
  // Load menu items dynamically from JSON if the menu container exists
  if (document.getElementById("menu-container")) {
    fetch("menu.json") // Fetch menu items from a local JSON file
      .then(response => response.json())
      .then(data => {
        const menuContainer = document.getElementById("menu-container");
        const popup = document.getElementById("popup");
        const popupTitle = document.getElementById("popup-title");
        const popupPrice = document.getElementById("popup-price");
        const popupImage = document.getElementById("popup-image");
        const closeBtn = document.querySelector(".close-btn");

        menuContainer.innerHTML = ""; // Clear any existing content

        // Iterate through each item and create a menu item element
        data.forEach(item => {
          const menuItem = document.createElement("div");
          menuItem.classList.add("menu-item");

          // Populate menu item HTML with data
          menuItem.innerHTML = `
            <img src="${item.image}" alt="${item.name}">
            <div>
              <h3>${item.name}</h3>
              <p>${item.description}</p>
              <p class="price">${item.price}</p>
              <button class="add-to-cart-btn">Add to Cart</button>
            </div>
          `;

          // Add item to cart without opening popup
          menuItem.querySelector(".add-to-cart-btn").addEventListener("click", (e) => {
            e.stopPropagation();
            addToCart(item);
          });

          // Display item details in a popup on click
          menuItem.addEventListener("click", () => {
            popupTitle.innerText = item.name;
            popupPrice.innerText = item.price;
            popupImage.src = item.image;
            popupImage.alt = item.name;
            popup.classList.remove("hidden");
          });

          menuContainer.appendChild(menuItem);
        });

        // Event to close popup when clicking the close button or outside popup
        closeBtn.addEventListener("click", () => popup.classList.add("hidden"));
        window.addEventListener("click", (e) => {
          if (e.target === popup) popup.classList.add("hidden");
        });
      })
      .catch(error => console.error("Error loading menu:", error));
  }

  // Handle contact form submission and store data in localStorage
  const contactForm = document.getElementById("contactForm");
  if (contactForm) {
    contactForm.addEventListener("submit", function (event) {
      event.preventDefault();

      let name = document.getElementById("name").value.trim();
      let email = document.getElementById("email").value.trim();
      let message = document.getElementById("message").value.trim();

      if (name && email && message) {
        let contactData = { name, email, message, date: new Date().toLocaleString() };
        localStorage.setItem("contactData", JSON.stringify(contactData)); // Save contact info
        document.getElementById("Modal").style.display = "block"; // Show confirmation modal
        contactForm.reset();
        loadContactData();
      } else {
        alert("Please fill out all fields.");
      }
    });

    // Load previously saved contact data from localStorage into form
    function loadContactData() {
      let savedContact = JSON.parse(localStorage.getItem("contactData"));
      if (savedContact) {
        document.getElementById("name").value = savedContact.name;
        document.getElementById("email").value = savedContact.email;
        document.getElementById("message").value = savedContact.message;
      }
    }

    loadContactData();
  }

  // Review form elements
  const reviewForm = document.getElementById("reviewForm");
  const reviewsContainer = document.getElementById("reviewsContainer");
  const clearReviewsBtn = document.getElementById("clearReviews");

  // Load and render reviews from localStorage
  function loadReviews() {
    const savedReviews = JSON.parse(localStorage.getItem("reviews")) || [];
    reviewsContainer.innerHTML = "";

    if (savedReviews.length === 0) {
      reviewsContainer.innerHTML = "<p>No reviews yet. Be the first to leave a review!</p>";
    } else {
      savedReviews.forEach((review, index) => {
        let reviewItem = document.createElement("div");
        reviewItem.classList.add("review-item");
        reviewItem.innerHTML = `
          <strong>${review.name} (${review.rating} Stars)</strong>
          <p>${review.text}</p>
          <small>Posted on ${review.date}</small>
          <button class="deleteReview" data-index="${index}">Delete</button>
        `;
        reviewsContainer.appendChild(reviewItem);
      });

      // Add delete functionality to each review
      document.querySelectorAll(".deleteReview").forEach(button => {
        button.addEventListener("click", function () {
          let index = this.getAttribute("data-index");
          let savedReviews = JSON.parse(localStorage.getItem("reviews")) || [];
          savedReviews.splice(index, 1);
          localStorage.setItem("reviews", JSON.stringify(savedReviews));
          loadReviews();
        });
      });
    }
  }

  // Save review to localStorage on form submission
  if (reviewForm) {
    reviewForm.addEventListener("submit", function (event) {
      event.preventDefault();
      let reviewerName = document.getElementById("reviewerName").value.trim();
      let rating = document.getElementById("rating").value;
      let reviewText = document.getElementById("reviewText").value.trim();

      if (reviewerName && rating && reviewText) {
        let reviewData = {
          name: reviewerName,
          rating: rating,
          text: reviewText,
          date: new Date().toLocaleString()
        };

        let savedReviews = JSON.parse(localStorage.getItem("reviews")) || [];
        savedReviews.push(reviewData);
        localStorage.setItem("reviews", JSON.stringify(savedReviews)); // Save new review
        document.getElementById("Modal").style.display = "block"; // Show modal after submit
        reviewForm.reset();
        loadReviews();
      } else {
        alert("Please fill out all fields.");
      }
    });
  }

  // Clear all reviews from localStorage when button clicked
  if (clearReviewsBtn) {
    clearReviewsBtn.addEventListener("click", function () {
      localStorage.removeItem("reviews");
      loadReviews();
    });
  }

  loadReviews(); // Initial call to load any existing reviews

  // Highlight the current page in navigation menu
  function highlightActivePage() {
    let navLinks = document.querySelectorAll("nav ul li a");
    let currentPath = window.location.pathname.split("/").pop();

    navLinks.forEach(link => {
      if (link.getAttribute("href") === currentPath) {
        link.classList.add("active");
      } else {
        link.classList.remove("active");
      }
    });
  }

  highlightActivePage(); // Initial call to highlight nav
});

// Handles user signup functionality
const signupForm = document.getElementById("signupForm");
if (signupForm) {
  signupForm.addEventListener("submit", function (e) {
    e.preventDefault();
    const email = document.getElementById("signupEmail").value.trim();
    const password = document.getElementById("signupPassword").value;

    if (email && password) {
      let users = JSON.parse(localStorage.getItem("users")) || [];
      const existingUser = users.find(user => user.email === email);
      if (existingUser) {
        document.getElementById("signupMessage").textContent = "Email already registered.";
        return;
      }

      users.push({ email, password });
      localStorage.setItem("users", JSON.stringify(users));
      document.getElementById("signupMessage").textContent = "Account created successfully!";
      signupForm.reset();
    } else {
      document.getElementById("signupMessage").textContent = "Please fill in all fields.";
    }
  });
}

// Handles user login functionality
const loginForm = document.getElementById("loginForm");
if (loginForm) {
  loginForm.addEventListener("submit", function (e) {
    e.preventDefault();
    const email = document.getElementById("loginEmail").value.trim();
    const password = document.getElementById("loginPassword").value;

    const users = JSON.parse(localStorage.getItem("users")) || [];
    const user = users.find(u => u.email === email && u.password === password);

    if (user) {
      document.getElementById("Modal").style.display = "block";
      window.location.href = "index.html";
    } else {
      document.getElementById("loginMessage").textContent = "Invalid email or password.";
    }
  });
}

// Loads and displays the number of items in the cart
function loadCartCount() {
  const cart = JSON.parse(localStorage.getItem("cart")) || [];
  const cartCount = document.getElementById("cartCount");
  if (cartCount) {
    cartCount.textContent = cart.reduce((sum, item) => sum + item.quantity, 0);
  }
}
loadCartCount();

// Adds a selected item to the cart
function addToCart(item) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  const existing = cart.find(c => c.name === item.name);
  if (existing) {
    existing.quantity += 1;
  } else {
    cart.push({ ...item, quantity: 1 });
  }
  localStorage.setItem("cart", JSON.stringify(cart));
  document.getElementById("Modal").style.display = "block";
  loadCartCount();
}

// Renders the cart page with all cart items and their totals
function renderCartPage() {
  const container = document.getElementById("cartItemsContainer");
  if (!container) return;
  const cart = JSON.parse(localStorage.getItem("cart")) || [];
  if (cart.length === 0) {
    container.innerHTML = "<p>Your cart is empty.</p>";
    document.getElementById("cartTotal").textContent = "0.00";
    return;
  }
  let total = 0;
  container.innerHTML = "";
  cart.forEach((item, index) => {
    const itemTotal = parseFloat(item.price.replace("$", "")) * item.quantity;
    total += itemTotal;
    const div = document.createElement("div");
    div.className = "cart-item";
    div.innerHTML = `
      <div><strong>${item.name}</strong><br><small>${item.price}</small></div>
      <div>
        <button id="btnadd" onclick="changeQuantity(${index}, -1)">-</button>
        <span>${item.quantity}</span>
        <button id="btnsub" onclick="changeQuantity(${index}, 1)">+</button>
      </div>
      <div>
        <p>$${itemTotal.toFixed(2)}</p>
        <button onclick="removeCartItem(${index})">Remove</button>
      </div>
    `;
    container.appendChild(div);
  });
  document.getElementById("cartTotal").textContent = total.toFixed(2);
}

// Changes the quantity of a cart item, adds or removes it
function changeQuantity(index, delta) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  cart[index].quantity += delta;
  if (cart[index].quantity <= 0) cart.splice(index, 1);
  localStorage.setItem("cart", JSON.stringify(cart));
  renderCartPage();
  loadCartCount();
}

// Removes an item from the cart based on its index
function removeCartItem(index) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  cart.splice(index, 1);
  localStorage.setItem("cart", JSON.stringify(cart));
  renderCartPage();
  loadCartCount();
}

// Clears the entire cart
const clearCartBtn = document.getElementById("clearCartBtn");
if (clearCartBtn) {
  clearCartBtn.addEventListener("click", () => {
    localStorage.removeItem("cart");
    renderCartPage();
    loadCartCount();
  });
}

renderCartPage();

// Toggles navigation bar visibility on mobile
const hamburger = document.getElementById("hamburger");
const navbar = document.getElementById("navbar");

if (hamburger && navbar) {
  hamburger.addEventListener("click", () => {
    navbar.classList.toggle("show");
  });
}

// Closes modal when close button is clicked
const closeModal = document.getElementById("closeModal");
if (closeModal) {
  closeModal.addEventListener("click", () => {
    document.getElementById("Modal").style.display = "none";
  });
}

// Closes modal when clicking outside of it
window.addEventListener("click", function(event) {
  const modal = document.getElementById("Modal");
  if (event.target === modal) {
    modal.style.display = "none";
  }
});
